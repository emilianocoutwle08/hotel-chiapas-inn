// Datos de ejemplo de habitaciones
let habitaciones = [
    { id: 1, tipo: "Sencilla", precio: 100, estado: "Disponible" },
    { id: 2, tipo: "Doble", precio: 150, estado: "Disponible" },
    { id: 3, tipo: "Familiar", precio: 200, estado: "Ocupada" },
    { id: 4, tipo: "Suite", precio: 300, estado: "Disponible" },
    { id: 5, tipo: "Prime", precio: 400, estado: "Ocupada" }
];

let reservas = [];
let huespedes = [];
let habitaciones_registradas = [];
let empleados = [];
let servicios = [];

function mostrarSeccion(seccion) {
    const secciones = document.querySelectorAll(".seccion");
    secciones.forEach(section => section.style.display = "none");
    document.getElementById(seccion).style.display = "block";
}

// Cargar las habitaciones disponibles en el formulario de reserva
function cargarHabitaciones() {
    const selectHabitacion = document.getElementById("tipo_habitacion");
    habitaciones.forEach(habitacion => {
        const option = document.createElement("option");
        option.value = habitacion.id;
        option.textContent = `${habitacion.tipo} - $${habitacion.precio}`;
        selectHabitacion.appendChild(option);
    });
}

// Registrar una reserva
function registrarReserva() {
    const nombre = document.getElementById("nombre_cliente").value;
    const apellidoPaterno = document.getElementById("apellido_paterno").value;
    const apellidoMaterno = document.getElementById("apellido_materno").value;
    const direccion = document.getElementById("direccion").value;
    const telefono = document.getElementById("telefono").value;
    const email = document.getElementById("email").value;
    const habitacionId = document.getElementById("tipo_habitacion").value;
    const checkIn = document.getElementById("check_in").value;
    const checkOut = document.getElementById("check_out").value;
    const estadoReserva = document.getElementById("estado_reserva").value;
    const fechaReserva = new Date().toLocaleDateString();

    const reserva = {
        id: reservas.length + 1,
        nombre,
        apellidoPaterno,
        apellidoMaterno,
        direccion,
        telefono,
        email,
        habitacionId,
        checkIn,
        checkOut,
        estadoReserva,
        fechaReserva
    };

    reservas.push(reserva);
    alert("Reserva registrada correctamente");
    mostrarSeccion("registros");
    mostrarRegistros();
}

// Mostrar los registros de reservas
function mostrarRegistros() {
    let registrosHTML = "<h3>Lista de Reservas:</h3><ul>";
    reservas.forEach(reserva => {
        registrosHTML += `
            <li>
                ${reserva.nombre} ${reserva.apellidoPaterno} ${reserva.apellidoMaterno} - Habitación: ${habitaciones[reserva.habitacionId - 1].tipo} - Fecha de Reserva: ${reserva.fechaReserva}
            </li>
        `;
    });
    registrosHTML += "</ul>";
    document.getElementById("registros").innerHTML = registrosHTML;
}

window.onload = () => {
    cargarHabitaciones();
};
